# Health
Proyect to graph the numbers of pacients with normal health, prediabetes and diabetes
Once you run the code in the terminal you have to write (Male/male or Female/female) as input to see the results
